#### Themenbereich
Programmieren mit PHP - Basis

## Themenbereich

# Übung 6

## Aufgabe

In der Datei `game.json` ist ein Tetris-Spiel (jede einzelne Aktion des Spielers und des Spiels selbst wie beispielsweise bewegen nach links, bewegen nach rechts, rotieren, Löscher einer Zeile, etc.) gespeichert. In der Datei `game.php` wird das Protokoll des Spiels bereits für Sie geladen.

Aufgaben:

1. Durchlaufen Sie das Protokoll und finden Sie jenen Eintrag, wo zum ersten Mal eine Zeile vollständig ist und gelöscht wird. Geben Sie den Eintrag mit `var_dump()` aus.

2. Geben Sie den Zustand des Spiels **vor dem Löschen der Zeile** als HTML-Tabelle aus. Das Spielfeld ist im Protokoll in Zeilen und Spalten gespeichert, eine Ausgabe als Tabelle bietet sich also an.

Optional:

3. Markieren Sie in der HTML-Tabelle die zu löschende Zeile, beispielsweise mit einer anderen Farbe.

Im Detail bleibt die tabellarische Darstellung als HTML-Tabelle Ihnen überlassen, Sie können sich aber an der HTML-Darstellung in `tetris/static` orientieren. Befüllte Spielfelder können mit "X" als Text befüllt werden oder es kann beispielsweise eine Hintergrundfarbe oder CSS-Klasse gesetzt werden.
