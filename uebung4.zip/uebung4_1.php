<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php 

//CSV wird gelesen
$file = fopen('SampleCSVFile_119kb.csv' , 'r');


if ($file != false) {
    $dataArray = [];
    $ignore = false;

    // $file wird Zeilenzeise in das Array $dataArray eingelesen
    while ($row = fgets($file)){
        $dataArray[] = $row;
    }
    echo '<table>';

    // $dataArray wird ausgegeben und in Zeile Spalte geteilt
    foreach ($dataArray AS $arrayRow) {
        echo '<tr><td>';
    /**
     * Es wird Zeichen pro Zeichen ausgelesen und bei Kommas in Spalten getrennt. 
     * Wenn ein "-Anführungszichen kommt, dann ignoriere so lange alle Kommas zum trennen bis das nächste 
     * Anführungszeichen dies wieder beendet. 
     */
        // Liest die Zeile pro Character (Zeichen) aus. 
        for ($i = 0; $i < strlen($arrayRow); $i++) {
            $character = $arrayRow[$i];

            // Wenn das letzte Zeichen erreicht ist, schließe die Tabellenreihe und öffne eine neue
            if ($character == '\n') {
                echo '<tr>' . $character . '</tr>';
                echo '</td><td>';

            /**
             * Wenn das Anführngszeichen da ist, prüfe ob die Variable $ignore auf false steht. Ist dies der Fall,
             * dann stelle $ignore auf true. Andernfalls stelle sicher, dass $ignore auch wirklich false ist.
             */
            } elseif ($character == '"' ) {

                if ($ignore == false) {
                    $ignore = true;

                } else {
                    $ignore = false;

                }
                /**
                 * Solange die Variable $ignore auf false ist und das Zeichen ein ,-Komma ist, erstelle eine neue Spalte
                 */
            } elseif ($character == ',' && $ignore == false) {
                echo '</td><td>';
                $ignore = false;
            
            // Ist keine Bedingung true, gib einfach nur das Zeichen aus
            } else {
                echo $character;

            }
            
        }
        echo '</tr>';
        
    }
    echo '</table>';
}
?>
</body>
</html>