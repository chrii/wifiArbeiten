<?php
class SpiderstrapForms {
    protected $name;
    protected $type;
    protected $id;
    protected $config = [];

    public function __construct(array $config){

        $this->config = $config;

        if (array_key_exists('username', $config) && array_key_exists('password', $config)){
            $this->username = $config['username'];
            $this->password = $config['password'];
        }
    }

    public function renderLogin(){
        $out = '';
        $out .= '<form class="px-4 py-3" action="" method="post">'.
                '<div class="form-group">'.
                $this->renderLabel($this->username).
                $this->renderInput($this->username).
                '</div><div class="form-group">'.
                $this->renderLabel($this->password).
                $this->renderInput($this->password).
                '</div><button type="submit" class="btn btn-primary">Login</button></form>';
        
        return $out;
    }

    public function renderLabel($val){
        $out = '';
        $out .= '<label for="' . $val['id'] . '" >'.
                $val['label'].
                '</label>';
        return $out;
    }

    public function renderInput($val) {
        $out = '';
        $out .= '<input type="' . $val['type'] . '" '.
                'id="' . $val['id'] . '" '.
                'name="' . $val['name'] . '" class="form-control"> ';
        return $out;
    }

    public function errorHandlerArray(array $val) {
        $out = '';
        if (!empty($val)) {
            foreach ($val AS $row){
                $out .= '<div class="alert alert-danger" role="alert">' . 
                        $row . '</div>';
            }
        }
        return $out;
    }
    
}

/*<form class="px-4 py-3" action="" method="post">
<div class="form-group">
    <label for="exampleDropdownFormEmail1">Username</label>
    <input type="text" class="form-control" id="exampleDropdownFormEmail1" name="username" placeholder="User">
</div>
<div class="form-group">
    <label for="exampleDropdownFormPassword1">Passwort</label>
    <input type="password" class="form-control" id="exampleDropdownFormPassword1" name="password" placeholder="Passwort">
</div>
<div class="form-check">
    <input type="checkbox" class="form-check-input" id="dropdownCheck">
    <label class="form-check-label" for="dropdownCheck">
        Remember me
    </label>
</div>
<button type="submit" class="btn btn-primary">Login</button>
</form>*/