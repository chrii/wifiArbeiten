<?php 
require_once 'misc/init.php';
require_once 'misc/check-login.php';

require_once 'layout/head.php';
?>

</head>
<body>

  <?php 
  require_once 'layout/nav-bar.php'; 
  ?>
<header class="container header">
  <h1>Willkommen</h1>
</header>
<main class="container">
<div class="row">
  <div class="col-auto mr-auto">
  </div>
    <div class="col-8">
      <?php
      if ($user->loggedIn($_SESSION) === true){
        require_once 'misc/game.php';
      } else {
        require_once 'misc/login.php';
      }
      ?>
    </div>
  <div class="col-auto mr-auto">
  </div>
</div>
</main>

  <?php 
  require_once 'layout/footer.php';
  ?>
