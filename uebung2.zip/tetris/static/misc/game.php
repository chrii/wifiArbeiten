<div class="row justify-content-center tetris-display">
    <div class="col-4 display-border">
        <div class="container tetris">
            <div class="row" rv-each-row="game:map:rows">
                <div class="col-sm" rv-each-cell="row" rv-class="cell:class">&nbsp;</div>
            </div>
        </div>
    </div>
    <div class="col-4">
        <div class="container">
            <h4 class="text-center tetris-style-boxed">Score</h4>
            <h5 class="text-center"><span rv-text="game:points"></span></h5>
            <h6 class="text-center tetris-style-boxed">Zeilen <span rv-text="game:lines"></span></h6>
            <h6 class="text-center tetris-style-boxed">Level <span rv-text="game:level.name"></span></h6>
        </div>
    </div>
</div>