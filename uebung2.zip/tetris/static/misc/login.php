<div class="card">
    <div class="card-body">
        <?php 
        $bootstrap = new SpiderstrapForms($config);
        
        echo $bootstrap->errorHandlerArray($errors);

        echo $bootstrap->renderLogin();

        ?>
    </div>
</div> 

