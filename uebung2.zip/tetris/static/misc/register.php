<div class="card">
  <div class="card-body">
    <form>
      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="username">Username</label>
          <input type="text" class="form-control" id="username" placeholder="Name eintragen...">
        </div>
        <div class="form-group col-md-6">
          <label for="inputCity">Email</label>
          <input type="email" class="form-control" id="inputCity" placeholder="Email">
        </div>

      </div>
      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="inputPassword4">Passwort</label>
          <input type="password" class="form-control" id="inputPassword4" placeholder="Passwort">
        </div>
        <div class="form-group col-md-6">
          <label for="inputPassword4">Passwort bestätigen</label>
          <input type="passwordConfirm" class="form-control" id="inputPassword4" placeholder="Passwort">
        </div>
      </div>
      <div class="form-group">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="gridCheck">
          <label class="form-check-label" for="gridCheck">
            Check me out
          </label>
        </div>
      </div>
      <button type="submit" class="btn btn-primary">Registrieren</button>
    </form>
  </div>
</div>