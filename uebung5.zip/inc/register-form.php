<div class="p-5">
      <form action="" method="post" novalidate>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="inputEmail4">Email-Adresse</label>
            <input type="email" name="email" class="form-control" id="inputEmail4" placeholder="Email-Adresse">
            <?= errorCodes('email' , $errors) ?>
          </div>
          <div class="form-group col-md-6">
            <label for="inputPassword4">Passwort</label>
            <input type="password" name="password" class="form-control" id="inputPassword4" placeholder="Passwort">
            <?= errorCodes('password' , $errors) ?>
          </div>
        </div>
        <div class="form-group">
          <label for="inputAddress">Adresse</label>
          <input type="text" name="adresse" class="form-control" id="inputAddress" placeholder="Musterstraße 123">
          <?= errorCodes('adresse' , $errors) ?>
        </div>
        <div class="form-group">
          <label for="inputAddress2">Adresse 2</label>
          <input type="text" name="adresse2" class="form-control" id="inputAddress2" placeholder="Stiege, Stock, Türnummer, ...">
        </div>
        <div class="form-row">
          <div class="form-group col-md-2">
            <label for="inputZip">Postleitzahl</label>
            <input type="text" name="plz" class="form-control" id="inputZip">
            <?= errorCodes('plz' , $errors) ?>
          </div>
          <div class="form-group col-md-6">
            <label for="inputCity">Stadt</label>
            <input type="text" name="city" class="form-control" id="inputCity">
            <?= errorCodes('city' , $errors) ?>
          </div>
          <div class="form-group col-md-4">
            <label for="inputState">Bundesland</label>
            <select name="bundesland" id="inputState" class="form-control">
              <option selected value="">auswählen...</option>
              <option>Wien</option>
              <option>Burgenland</option>
              <option>Niederösterreich</option>
              <option>Oberösterreich</option>
              <option>Kärnten</option>
              <option>Steiermark</option>
              <option>Vorarlberg</option>
              <option>Tirol</option>
              <option>Salzburg</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <div class="form-check">
            <input name="agb" class="form-check-input" type="checkbox" id="gridCheck">
            <label class="form-check-label" for="gridCheck">
              Ich habe die <a href="#">AGBs</a> gelesen und akzeptiere diese.
            </label>
          </div>
            <?= errorCodes('agb' , $errors) ?>
        </div>
        <button type="submit" class="btn btn-primary">Sign in</button>
      </form>
    </div>