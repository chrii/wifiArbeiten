<?php 

function errorCodes($val, $array) {
    if (array_key_exists($val, $array)) {
        return '<sub>' . $array[$val] . '</sub>';
    }
}