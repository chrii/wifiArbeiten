<?php
$formFields = [
    'email' => [
        'label' => 'E-Mail',
        'required' => true,
        'dataType' => 'email'
    ],
    'password' => [
        'label' => 'Passwort',
        'required' => true,
        'dataType' => 'password',
        'min_len' => 8
    ],
    'bundesland' => [
        'label' => 'Bundesland',
        'required' => true,
        /* 
            datatype whitelist prüft, ob der übergebene Wert einer Reihe von vorgegebenen Werten entspricht. whitelist benötigt ein Array 'options', um vergleichen zu können
        */
        'dataType' => 'whitelist',
        'options' => [
            'Wien',
            'Burgenland',
            'Niederösterreich',
            'Oberösterreich',
            'Kärnten',
            'Steiermark',
            'Vorarlberg',
            'Tirol',
            'Salzburg'
        ] // ende options
    ], // ende bundesland
    'plz' => [
        'label' => 'Postleitzahl',
        'dataType' => 'int',
        'required' => true,
        'min_len' => 4

    ]
];
$formFields['email']['required'];
$errors = [];
$formOK = false;

// wurde gepostet?
if (empty($_POST) == false) {
    foreach ($formFields as $name => $conf):
        // aktuellen Wert auslesen, wenn nicht übertragen => Leerstring
        $fieldVal = $_POST[$name] ?? '';
        $fieldVal = trim($fieldVal);

        if ($conf['required'] == true && $fieldVal == '') {
            $errors[$name] = $conf['label'] . ' ist auszufüllen';
            continue;
        }
        // ist das Feld nicht required und leer, dann ist alles ok, keine weitere Validerung nötig
        elseif (!$conf['required'] && $fieldVal == '') {
            continue;
        }

        // Datatype prüfen
        $dataTypeOk = false;
        switch ($conf['dataType']):
            case 'email':
                if (checkEmail($fieldVal) == false) {
                    $errors[$name] = $conf['label'] . ' ist keine gültige E-Mail Adresse';
                }
                else {
                    $dataTypeOk = true;
                }
                break;
            case 'password':
                // Kleinbuchstaben prüfen 
                if (!preg_match("([a-z])", $fieldVal)) {
                    $errors[$name] = $conf['label'] . ' muss mindestens einen Groß-, einen Kleinbuchstaben, eine Zahl und ein Sonderzeichen enthalten';
                    
                }
                elseif (!preg_match("([A-Z])", $fieldVal)) {
                    $errors[$name] = $conf['label'] . ' muss mindestens einen Groß-, einen Kleinbuchstaben, eine Zahl und ein Sonderzeichen enthalten';
                }
                elseif (!preg_match("([0-9])", $fieldVal)) {
                    $errors[$name] = $conf['label'] . ' muss mindestens einen Groß-, einen Kleinbuchstaben, eine Zahl und ein Sonderzeichen enthalten';
                }
                // regex prüft, ob Sonderzeichen vorkommen, ist true, wenn es vorkommt
                elseif (!preg_match("([^A-Za-z0-9])", $fieldVal)) {
                    $errors[$name] = $conf['label'] . ' muss mindestens einen Groß-, einen Kleinbuchstaben, eine Zahl und ein Sonderzeichen enthalten';
                }
                else {
                    $dataTypeOk = true;
                }
                break;
            case 'whitelist':
                // Prüfen, ob der übergebene Wert in einer Liste vorgegebener Werte vorkommt
                if (in_array($fieldVal, $conf['options']) == false) {
                    $errors[$name] = $conf['label'] . ' beinhaltet einen ungültigen Wert.';
                }
                else {
                    $dataTypeOk = true;
                }

                break;
            case 'int':
                if (!checkInt($fieldVal)) {
                    $errors[$name] = $conf['label'] . ' muss eine Zahl sein.';
                }
                else {
                    $dataTypeOk = true;
                }
                break;
        endswitch;

        if ($dataTypeOk == false) {
            continue;
        }

        // min/max prüfen
        $min_len = $conf['min_len'] ?? '';
        $max_len = $conf['max_len'] ?? '';

        dump($min_len);

        if ($min_len != '' && $max_len != '') {
            if ( $min_len > strlen($fieldVal) && $max_len < strlen($fieldVal) ){
                $errors[$name] = 'Das Feld muss mindestens ' . $conf[$min_len] . ' Zeichen und höchstens' . $conf[$max_len] . ' haben.';
            }
        }

    endforeach;

    // generelle Validierungen sind beendet, jetzt spezielle, nicht vordefinierbare Validierungen vornehmen.
    if (empty($errors['plz']) && empty($errors['bundesland'])) { // nur weiter prüfen, wenn plz ok
        $plzVal = $_POST['plz'] ?? '';
        $blVal = $_POST['bundesland'] ?? '';

        $bl = [
            'Wien' => [1000, 1999],
            'Burgenland' => [7000, 7999],
            'Niederösterreich' => [2000, 3999],
            'Oberösterreich' => [4000, 4999],
            'Kärnten' => [9000, 9999],
            'Steiermark' => [8000, 8999],
            'Vorarlberg' => [6700, 6999],
            'Tirol' => [6000, 6699],
            'Salzburg' => [5000, 5999]
        ];
        
        // aus dem jeweiligen Bundesland Minimum und Maximum auslesen
        $min = $bl[$blVal][0];
        $max = $bl[$blVal][1];

        // Prüfen, ob die übergeben PLZ im gültigen Bereich des Bundeslandes ist
        if ($plzVal < $min || $plzVal > $max) {
            $errors[$name] = $formFields['plz']['label'] . ' enthält keine gültige Postleitzahl für ' .  $blVal;
            
        }

    }
    if (!array_key_exists('agb', $_POST)) {
        $errors[$name] = "Bitte lesen Sie die Allgemeinen Geschäftsbedingungen";
    }
    if (empty($errors)) {
        $formOK = true;
        echo $formOK;
    }
} // ende empty($_POST)
