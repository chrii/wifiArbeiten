<h2>Danke!</h2>
<p>Vielen Dank, dass Sie sich registriert haben! Wir verkaufen jetzt ihre Daten weiter.</p>
